from tkinter import *

def val(value):
    lbl.config(text=value)

root = Tk()
root.title("Mon application")
root.geometry('800x600+600+200')

scale = Scale(root, orient=HORIZONTAL, length=400, from_=-100, to=100,
              label="Scale widget", showvalue=False, command=val)
scale.pack()

lbl = Label(root, font="Arial 20")
lbl.pack()

root.mainloop()