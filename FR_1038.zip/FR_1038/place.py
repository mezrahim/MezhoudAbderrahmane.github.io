from tkinter import *

root = Tk()
root.title("Mon application")
root.geometry('800x600+600+200')

lbl = Label(root, text="Label 1", bg="white", font="Arial 30")
lbl.place(x=0, y=100, relwidth=0.2, relheight=0.2)

lbl1 = Label(root, text="Label 1", bg="white", font="Arial 30")
lbl1.place(relx=0, rely=0)

lbl2 = Label(root, text="Label 2", bg="red", font="Arial 30")
lbl2.place(relx=0, rely=1, anchor=SW)

lbl3 = Label(root, text="Label 3", bg="blue", font="Arial 30")
lbl3.place(relx=1, rely=0, anchor=NE)

lbl4 = Label(root, text="Label 4", bg="green", font="Arial 30")
lbl4.place(relx=1, rely=1, anchor=SE)

lbl5 = Label(root, text="Label 5", bg="yellow", font="Arial 30")
lbl5.place(relx=.5, rely=.5, anchor=CENTER)

root.mainloop()