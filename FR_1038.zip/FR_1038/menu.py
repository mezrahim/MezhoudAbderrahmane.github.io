from tkinter import *

def execute_code():
    print("Execution du code")

root = Tk()
root.title("Mon application")
root.geometry('800x600+600+200')

main_menu = Menu(root)
root.config(menu=main_menu)

menu1 = Menu(main_menu, tearoff=False)
main_menu.add_cascade(label="Menu1", menu=menu1)
menu1.add_command(label="Option 1", command=execute_code)
menu1.add_command(label="Option 2", command=execute_code)
menu1.add_command(label="Option 3", command=execute_code)

submenu1 = Menu(menu1, tearoff=False)
menu1.add_separator()
menu1.add_cascade(label="SubMenu1", menu=submenu1)
submenu1.add_command(label="Option sous menu 1", command=execute_code)
submenu1.add_command(label="Option sous menu 2", command=execute_code)
menu2 = Menu(main_menu, tearoff=False)
main_menu.add_cascade(label="Menu2", menu=menu2)
menu2.add_command(label="Choix 1", command=execute_code)
menu2.add_command(label="Choix 2", command=execute_code)
menu2.add_command(label="Choix 3", command=execute_code)



root.mainloop()
