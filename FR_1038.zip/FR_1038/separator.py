from tkinter import *
from tkinter import ttk

root = Tk()
root.title("Mon application")
root.geometry('800x600+600+200')

lbl1 = Label(root, text="Une ligne de texte dans un label", font="Dubai 20")
lbl1.pack()

sep = ttk.Separator(root, orient=HORIZONTAL)
sep.pack(fill=X)

lbl2 = Label(root, text="Une autre ligne de texte dans un label", font="Dubai 20")
lbl2.pack()
root.mainloop()