from tkinter import *

root = Tk()
root.title("Mon application")
root.geometry('800x600+600+200')

lbl = Label(root, text="Ceci est un widget label", bg="black", fg="white", font="Arial 20")
lbl.pack(expand=True)

def on_enter(event):
    lbl.config(bg="red")
lbl.bind("<Enter>", on_enter)

def on_leave(event):
    lbl.config(bg="black")
lbl.bind("<Leave>", on_leave)

btn = Button(text="Cliquez moi", font="Arial 20")
btn.pack(pady=200)

def on_left_click(event):
    lbl.config(text="Vous avez cliquez avec le bouton gauche sur le bouton")
btn.bind("<Button-1>", on_left_click)

def on_right_click(event):
    lbl.config(text="Vous avez cliquez avec le bouton droit sur le bouton")
btn.bind("<Button-3>", on_right_click)

def on_double_left_click(event):
    lbl.configure(text="Double clique gauche")
lbl.bind("<Double-Button-1>", on_double_left_click)

root.mainloop()
