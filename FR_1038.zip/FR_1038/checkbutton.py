from tkinter import *

root = Tk()
root.title("Mon application")
root.geometry('800x600+600+200') 

var1 = BooleanVar()
check1 = Checkbutton(root, text="Option 1", variable=var1)
check1.pack()

var2 = BooleanVar()
check2 = Checkbutton(root, text="Option 2", variable=var2)
check2.pack()

var3 = BooleanVar()
check3 = Checkbutton(root, text="Option 3", variable=var3)
check3.pack()

def val():
    selected = []
    if var1.get():
        selected.append(check1.cget("text"))
    if var2.get():
        selected.append(check2.cget("text"))
    if var3.get():
        selected.append(check3.cget("text"))
    print("Vous avez selectioné :")
    for item in selected:
        print(item)



btn = Button(root, text="Validation", command=val)
btn.pack()

root.mainloop()
