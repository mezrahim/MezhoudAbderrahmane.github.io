from tkinter import *

def convert():
    euro = float(euro_entry.get())
    dollar = euro * 1.1
    dollar_label.config(text=str(dollar) + "$")

# Creation de la fenetre principale
root = Tk()
root.geometry("250x100")
root.title("Convertisseur euro/dollar")

# Creation du label pour afficher l'indication
lbl = Label(root, text="Entrez une somme en euro")
lbl.pack()

# Creation du widget Entry pour entrer la somme en euro
euro_entry = Entry(root)
euro_entry.pack()

# Creation du bouton de conversion
convert_button = Button(root, text="Convertir", command=convert)
convert_button.pack()

# Creation du label pour afficher le montant en dollar
dollar_label = Label(root)
dollar_label.pack()

root.mainloop()