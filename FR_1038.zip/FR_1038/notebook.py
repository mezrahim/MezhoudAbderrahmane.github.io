from tkinter import *
from tkinter import ttk

root = Tk()
root.title("Mon application")
root.geometry('800x600+600+200')

notebook = ttk.Notebook(root, width=800, height=600)
notebook.pack()

page1 = Frame(notebook)
lbl1 = Label(page1, text="Contenu de la page 1")
lbl1.pack()
btn1 = Button(page1, text="Bouton")
btn1.pack()
notebook.add(page1, text="Page 1")

page2 = Frame(notebook)
lbl2 = Label(page2, text="Contenu de la page 2")
lbl2.pack()
notebook.add(page2, text="Page 2")

root.mainloop()