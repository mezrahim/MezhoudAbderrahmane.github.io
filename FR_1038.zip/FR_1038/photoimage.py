from tkinter import *

root = Tk()
root.title("Mon application")
root.geometry('800x600+600+200') 

photo = PhotoImage(file="python.png")
photo_resized = photo.subsample(2,2)
photo_resized2 = photo.zoom(1)
lbl_image = Label(root, image=photo)
lbl_image.pack()

btn = Button(root, text="Cliquez moi", width=150, height=50, compound="left")
img = PhotoImage(file="python.png")
img_resized = img.subsample(8,8)
btn.config(image=img_resized)
btn.pack()

root.mainloop()
