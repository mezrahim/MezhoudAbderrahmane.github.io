from tkinter import *

root = Tk()
root.title("Mon application")
root.geometry('800x600+600+200')

my_font = "Arial 20"

lbl = Label(root, text="Ceci est un widget label", font=my_font)
lbl.pack(pady=20)

def start():
    root.after(5000, lambda: lbl.config(text="Il s'est écoulé 5 secondes"))
btn = Button(root, text="Start", font=my_font, command=start)
btn.pack(pady=20)

nb=0
def increment():
    global nb
    nb+=1
    lbl.config(text=nb) 
    global compteur   
    compteur = root.after(1000, increment)

btn2 = Button(root, text="Repeat", font=my_font, command=increment)
btn2.pack(pady=20)

def stop():
    root.after_cancel(compteur)

btn3 = Button(root, text="Stop", font=my_font, command=stop)
btn3.pack(pady=20)

root.mainloop()

