from tkinter import *
from tkinter import filedialog

root = Tk()
root.title("Mon application")
root.geometry('800x600+600+200')

lbl = Label(root, font="Arial 10")
lbl.pack()


def choose_folder():
    folder =  filedialog.askdirectory(title="Dossier de destionation", initialdir="c:/")
    lbl.config(text=folder)
btn = Button(root, text="Selection dossier", command=choose_folder)
btn.pack()

def choose_file():
    file_path = filedialog.askopenfilename(title="selection fichier jpg", 
                filetypes=(("image jpg","*.jpg"), ("all","*.*")))
    lbl.config(text=file_path)
btn1 = Button(root, text="Selection fichier", command=choose_file)
btn1.pack()

def choose_files():
    files_path = filedialog.askopenfilenames(title="selection fichiers jpg", 
                filetypes=(("image jpg","*.jpg"), ("all","*.*")))
    lbl.config(text=files_path)
    for file in files_path:
        print(file)

btn2 = Button(root, text="Selection fichiers", command=choose_files)
btn2.pack()

def save_file():
    file = filedialog.asksaveasfile(title="Save as", mode="w", defaultextension=".txt")
    if(file is None):
        return
    text = "Hello world"
    file.write(text)
    file.close()

btn3 = Button(root, text="Enregistre sous", command=save_file)
btn3.pack()



root.mainloop()