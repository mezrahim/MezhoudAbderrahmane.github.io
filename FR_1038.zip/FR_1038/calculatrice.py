from tkinter import *

def calculate():
    try:
        result = eval(entry.get())
        entry.delete(0, END)
        entry.insert(0, result)
    except:
        entry.delete(0, END)
        entry.insert(0,"error")

def clear():
    entry.delete(0,END)    

root = Tk()
root.title("Calculatrice")
root.resizable(False,False)

entry = Entry(root, width=30, borderwidth=5)
entry.pack(side=TOP, padx=10, pady=10)

buttons = [
    "1","2","3","+",
    "4","5","6","-",
    "7","8","9","*",
    "0",".","=","/",
    "Effacer", "Quitter"
]

button_frame = Frame(root)
button_frame.pack(side=TOP, padx=10, pady=10)

r=0
c=0
for button in buttons:
    if button == "=":
        cmd = calculate
    elif button == "Effacer":
        cmd = clear 
    elif button == "Quitter":
        cmd = root.quit
    else:
        cmd = lambda x=button: entry.insert(END, x)

    Button(button_frame, text=button, width=7, height=3, command=cmd).grid(row=r,column=c, padx=5,pady=5)
    c+=1
    if c > 3:
        c=0
        r+=1

root.mainloop()
