from tkinter import *
from tkinter import messagebox

def mbox():
    reponse =  messagebox.askretrycancel("Titre", "Alors , c'est d'accord ?")
    if reponse==True:
        print("vous avez dit d'accord")
    else:
        print("vous n'etes pas d'accord")

root = Tk()
root.title("Mon application")
root.geometry('800x600+600+200') 

btn = Button(root, text="Show messagebox !", command=mbox)
btn.pack()

root.mainloop()
