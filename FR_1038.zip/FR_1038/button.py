from tkinter import *

def Affiche():
    lbl.config(text=btn.cget("text"))

root = Tk()
root.title("Mon application")
root.geometry('800x600+600+200') 

lbl = Label(root, font="Arial 33")
lbl.pack()

btn = Button(root, text="Cliquez moi", font='Arial 20', width=20, command=Affiche, bg="green")
btn.pack()

btn2 = Button(root, text="Clquez ici", font='Arial 20', width=20, 
              command=lambda:lbl.config(text="Vous avez cliqué sur le bouton"))
btn2.pack()

root.mainloop()