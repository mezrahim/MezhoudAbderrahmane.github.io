from tkinter import Tk

root = Tk()
root.title("Mon application")
root.geometry('800x600+600+200')
root.minsize(400,300)
root.maxsize(1000,800)
root.resizable(False,True)
root.iconbitmap("python.ico")
root.config(background="#87CEEB")
root.mainloop()