from tkinter import *

root = Tk()
root.title("Mon application")
root.geometry('800x600+600+200') 

radio_var = StringVar(value="o1")
radio1 = Radiobutton(root, text= "Option1", variable=radio_var, value="o1")
radio1.pack()

radio2 = Radiobutton(root, text= "Option2", variable=radio_var, value="o2")
radio2.pack()

radio3 = Radiobutton(root, text= "Option3", variable=radio_var, value="o3")
radio3.pack()

radio4 = Radiobutton(root, text= "Option4", variable=radio_var, value="o4")
radio4.pack()

def val():
    print("Vous avez selectionné : " + radio_var.get())
btn = Button(root, text="Validation",command=val)
btn.pack()

root.mainloop()
