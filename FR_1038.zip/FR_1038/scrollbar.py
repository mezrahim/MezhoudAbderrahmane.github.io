from tkinter import *

root = Tk()
root.title("Mon application")
root.geometry('200x250+600+200') 

scrollbar = Scrollbar(root)
scrollbar.pack(side=RIGHT, fill=Y)

list = Listbox(root, width=200, height=250, yscrollcommand=scrollbar.set)
for i in range(30):
    list.insert(i, "Element " + str(i))
list.pack()
list.selection_set(0)

scrollbar.config(command=list.yview)

root.mainloop()
