import csv
import random

class Question():

    list_questions = []

    def __init__(self):
        self.id = None
        self.question = None
        self.rep1 = None
        self.rep2 = None
        self.rep3 = None
        self.rep4 = None
        self.anecdote = None
        self.reponse = None
    
    def load_question(self):

        with open("questions.csv", encoding="utf-8") as csvfile:
            reader = csv.reader(csvfile, delimiter=";", quotechar="'")

            for item in reader:
                q=Question()
                q.id = item[0]
                q.question = item[2]
                q.rep1 = item[3]
                q.rep2 = item[4]
                q.rep3 = item[5]
                q.rep4 = item[6]
                q.anecdote = item[8]
                q.reponse = item[3]

                q.rep1, q.rep2, q.rep3, q.rep4 = random.sample([q.rep1, q.rep2,q.rep3,q.rep4], k=4)
                self.list_questions.append(q)

        q= random.choice(self.list_questions)
        return q
    
    def remove_question(self, q):
        self.list_questions.remove(q)



