from tkinter import *

root = Tk()
root.title("Mon application")
root.geometry('800x600+600+200') 

txt = Text(root, font="Arial 12", undo=True, wrap=WORD)
txt.pack()

txt.insert("1.0", "Une premiere ligne de texte\n")
txt.insert("2.0", "Une seconde ligne de texte\n")
txt.insert("3.0", "Une troisieme ligne de texte\n")

btn = Button(root, text="Lire", width=20, command=lambda:print(txt.get("4.0", "5.0")))
btn.pack()
root.mainloop()
