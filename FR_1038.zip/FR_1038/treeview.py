from tkinter import *
from tkinter import ttk

root = Tk()
root.title("Mon application")
root.geometry('800x600+600+200')

tree = ttk.Treeview(root, columns=("Nom","Prenom","Age"))
tree.heading("#0",text="ID")
tree.heading("Nom",text="Nom")
tree.heading("Prenom",text="Prenom")
tree.heading("Age",text="Age")
collegue_id = tree.insert("","end",text="Collegues")
tree.insert(collegue_id,"end",text="1", values=("Dupont", "jean", 25))
tree.insert(collegue_id,"end",text="2", values=("Martin", "Marie", 35))
tree.insert(collegue_id,"end",text="3", values=("Durand", "Paul", 42))
tree.insert("","end",text="4", values=("Dupont", "jean", 25))
tree.insert("","end",text="5", values=("Martin", "Marie", 35))
tree.insert("","end",text="6", values=("Durand", "Paul", 42))
tree.pack()

def prnt():
    selection = tree.selection()
    if selection:
        item = tree.item(selection)
        values = item["values"]
        print(values)

btn = Button(root, text="Read", width=40, command=prnt)
btn.pack()
root.mainloop()