from tkinter import *

root = Tk()
root.title("Mon application")
root.geometry('800x600+600+200')

btn1 = Button(root, text="Bouton 1", font="Arial 20")
btn2 = Button(root, text="Bouton 2", font="Arial 20")
btn3 = Button(root, text="Bouton 3", font="Arial 20")

btn1.grid(column=0, row=0, columnspan=2)
btn2.grid(column=1, row=1)
btn3.grid(column=2, row=1)

lbl = Label(root,text="Label")
lbl.pack()

root.mainloop()