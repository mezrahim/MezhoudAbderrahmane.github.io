from tkinter import *

root = Tk()
root.title("Mon application")
root.geometry('800x600+600+200')

var1 = StringVar()
lbl1 = Label(root, textvariable=var1)
lbl1.pack()

def get_mouse_position(event):
    x = event.x
    y = event.y
    var1.set("Position de la souris x:" + str(x) +" y:" + str(y))

root.bind("<Motion>", get_mouse_position)

var2 = StringVar()
lbl2 = Label(root, textvariable=var2)
lbl2.pack()

canvas = Canvas(root, bg="white", width=400, height=400)
canvas.create_rectangle(100,100,300,300, fill="red")
canvas.pack()

def click(event):
    if 100<event.x<300 and 100<event.y<300:
        var2.set("clique dans le carré rouge")
    else:
        var2.set("clique en dehors du carré rouge")
canvas.bind("<Button-1>", click)

root.mainloop()
