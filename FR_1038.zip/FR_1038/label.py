from tkinter import *

root = Tk()
root.title("Mon application")
root.geometry('800x600+600+200') 

lbl = Label(root, text="C'est un widget label", bg="white", font=("Arial",33,"bold"),
            fg="red", width=20, height=3, pady=50, padx=50)
lbl.pack()

lbl2 = Label(root,font=("Arial",33,"bold"),
            fg="white", width=20, height=3, pady=50, padx=50, bg="grey")
lbl2.pack()

print("Texte du label : " + lbl.cget("text"))
print("couleur du background du label : " + lbl.cget("bg"))
lbl2.configure(text="un autre widget")

root.mainloop()
