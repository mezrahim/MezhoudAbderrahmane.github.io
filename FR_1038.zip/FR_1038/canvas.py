from tkinter import *

root = Tk()
root.title("Mon application")
root.geometry('800x600+600+200')

canvas = Canvas(root, bg="White", width=500, height=500)

canvas.create_line(0,250,500,250, fill="red")
canvas.create_line(250,0,250,500, fill="red")

canvas.create_oval(300,50,450,200,fill="blue", outline="black", width=2)

canvas.create_arc(300,300,450,450, fill="yellow", outline="black", width=2, start=20, extent=280)

canvas.create_rectangle(50,50,200,200,fill="red", outline="black",width=2)

canvas.create_polygon(20,350,120,300,220,350,170,450,70,450, fill="green", outline="black", width=2)

python_image = PhotoImage(file="python.png")
canvas.create_image(250,250, image=python_image)

canvas.create_text(20,20,text="Mon Canevas", font="Dubai 20", anchor=W, fill="blue")

canvas.pack()

def quit_app():
    root.quit()
btn = Button(canvas,text="Cliquez moi", command=quit_app)
canvas.create_window(450,480, window=btn)

root.mainloop()