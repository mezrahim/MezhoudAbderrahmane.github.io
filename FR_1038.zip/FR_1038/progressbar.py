from tkinter import *
from tkinter import ttk

root = Tk()
root.title("Mon application")
root.geometry('800x600+600+200')

progress = ttk.Progressbar(root, value=0, orient=HORIZONTAL, length=400, mode='determinate')
progress.pack()

i=0
def update():
    global i
    i+=10
    progress.config(value=i)
    lbl.config(text=str(i)+ "%")

btn = Button(root, text="Update progressbar", command=update)
btn.pack()

lbl = Label(root)
lbl.pack()

root.mainloop()