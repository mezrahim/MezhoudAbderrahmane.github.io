from tkinter import *

root = Tk()
root.title("Mon application")
root.geometry('800x600+600+200')

frame = LabelFrame(root, text="LabelFrame", relief=GROOVE, labelanchor=N, borderwidth=2 )
frame.pack()

lbl = Label(frame,text="Ceci est un label")
lbl.pack()

lbl2 = Label(frame,text="Ceci est un label ,Ceci est un label")
lbl2.pack()

root.mainloop()