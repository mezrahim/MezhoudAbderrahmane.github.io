from tkinter import *

root = Tk()
root.title("Mon application")
root.geometry('800x600+600+200') 

list = Listbox(root)
for i in range(8):
    list.insert(i, "Element " + str(i))
list.pack()

list.select_set(0)
print("Nombre d'élements " + str(list.size()))
print(list.get(3, 5))

def del_element():
    list.delete(list.curselection())
btn1 = Button(root, text="Delete", command=del_element)
btn1.pack()

def prnt():
    print(list.get(list.curselection()))
btn1 = Button(root, text="Print", command=prnt)
btn1.pack()

def add():
    list.insert(list.size(), "Autre element")
btn1 = Button(root, text="Add", command=add)
btn1.pack()

root.mainloop()
