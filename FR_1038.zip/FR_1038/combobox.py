from tkinter import *
from tkinter import ttk

root = Tk()
root.title("Mon application")
root.geometry('800x600+600+200')

options = ["France", "Italie", "Espagne"]
combo = ttk.Combobox(root, values=options)
combo.pack()

combo.current(0)

btn1 = Button(root,text="Print selection", command=lambda:print(combo.get()))
btn1.pack()

def del_selection():
    selection = combo.current()
    options_list = list(combo["values"])
    options_list.pop(selection)
    combo["value"] = options_list
    combo.current(0)

btn2 = Button(root, text="Delete", command=del_selection)
btn2.pack()

def add():
    options_list = list(combo["values"])
    options_list.append("Belgique")
    combo["values"] = options_list

btn3 = Button(root,text="Add item", command=add)
btn3.pack()

root.mainloop()