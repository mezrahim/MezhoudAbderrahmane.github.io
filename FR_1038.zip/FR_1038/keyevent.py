from tkinter import *

root = Tk()
root.title("Mon application")
root.geometry('800x600+600+200')

canvas = Canvas(root, bg="green")
canvas.pack(fill=BOTH, expand=True)

carre = canvas.create_rectangle(400,300,450,350, fill="red")
x=0
y=0
def move(event):
    global x, y 
    if event.keysym == "Left":
        x=-5
        y=0
    if event.keysym == "Right":
        x=5
        y=0
    if event.keysym == "Up":
        x=0
        y=-5
    if event.keysym == "Down":
        x=0
        y=5
    canvas.move(carre,x, y)

for key in ["<Left>", "<Right>", "<Up>", "<Down>"]:
    root.bind(key, move)

'''
def ctrls(event):
    root.quit()
root.bind("<Control-s>", ctrls)
'''

'''
def press(event):
    print("Pressed : " + event.keysym)
root.bind("<KeyPress>", press)

def release(event):
    print("Release : " + event.keysym)
root.bind("<KeyRelease>", release)
'''
root.mainloop()
