from tkinter import *

root = Tk()
root.title("Mon application")
root.geometry('800x600+600+200')

menu_btn = Menubutton(root, text="Couleur", relief=RAISED)

var1 = IntVar()
var2 = IntVar()
var3 = IntVar()

menu1 = Menu(menu_btn, tearoff=False)

menu1.add_checkbutton(label="Bleu", variable=var1)
menu1.add_checkbutton(label="Blanc", variable=var2)
menu1.add_checkbutton(label="Rouge", variable=var3)

menu_btn["menu"]=menu1
menu_btn.pack()

def val():
    print("Vous avez selectionné")
    if(var1.get()):
        print("Bleu")
    if(var2.get()):
        print("Blanc")
    if(var3.get()):
        print("Rouge")

btn = Button(root, text="Validation", command=val)
btn.pack()
root.mainloop()
