from tkinter import *

class MonInterface(Tk):

    def __init__(self):
        super().__init__()
        self.title("Mon application")
        self.geometry("300x200")

        self.label = Label(self, text="Bienvenue dans mon application")
        self.label.pack(pady=20)

        self.label.bind("<Enter>", self.on_label_enter)
        self.label.bind("<Leave>", self.on_label_leave)

        self.button = Button(self, text="Cliquez moi", command=self.on_btn_click)
        self.button.pack(pady=20)

        self.mainloop()

    def on_label_enter(self, event):
        self.label.config(text="Vous êtes en train de survoler le label")

    def on_label_leave(self, event):
        self.label.config(text="Bienvenue dans mon application")

    def on_btn_click(self):
        self.label.config(text="Vous avez cliqué sur le bouton")

            
