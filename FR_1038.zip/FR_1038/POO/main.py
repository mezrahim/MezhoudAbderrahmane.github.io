from interface import MonInterface

root = MonInterface()