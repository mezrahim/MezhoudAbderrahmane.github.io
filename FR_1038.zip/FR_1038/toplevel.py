from tkinter import *

root = Tk()
root.title("Mon application")
root.geometry('800x600+600+200')

def show_window():
    window = Toplevel(root, bg="grey", relief=RAISED)
    window.transient(root)
    window.grab_set()
    window.focus_set()

btn = Button(root, text="New window", command=show_window)
btn.pack()
root.mainloop()