from tkinter import *
from tkinter.colorchooser import askcolor

root = Tk()
root.title("Mon application")
root.geometry('800x600+600+200')

lbl = Label(root, text="Ceci est une label texte", font ="Arial 15")
lbl.pack()

def set_color():
    color = askcolor(title="Choix de la couleur", initialcolor=(0,0,0))
    print("RVB " + str(color[0]))
    print("HEX " + str(color[1]))
    lbl.configure(foreground=color[1])

btn = Button(root, text="Choix couleur", command=set_color)
btn.pack()

root.mainloop()