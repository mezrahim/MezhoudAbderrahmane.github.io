from tkinter import *

root = Tk()
root.title("Mon application")
root.geometry('800x600+600+200')


lbl = Label(root,text="Je suis un label", font="Arial 20")
lbl.pack()

frm = Frame(bg="white")
frm.pack()

btn = Button(frm,text="Bouton 1", font="Arial 20")
btn.pack(side=LEFT,expand=1)

btn2 = Button(frm,text="Bouton 2", font="Arial 20")
btn2.pack(side=LEFT,expand=1)


root.mainloop()