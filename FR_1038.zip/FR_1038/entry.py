from tkinter import *

root = Tk()
root.title("Mon application")
root.geometry('800x600+600+200') 

ma_var= StringVar()
ma_var.set("votre prenom")
myfont = ("Arial", 20)

lbl = Label(root, font=myfont, textvariable=ma_var)
lbl.pack()

entry = Entry(root, font=myfont)
entry.pack()

btn = Button(root, text="Valider", font=myfont, command=lambda:ma_var.set(entry.get()))
btn.pack()

root.mainloop()